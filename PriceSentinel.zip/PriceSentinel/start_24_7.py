"""
Модуль для запуска бота в режиме 24/7.
Запускает бота и добавляет дополнительные проверки для поддержания работы.
"""

import os
import sys
import time
import logging
import threading
import subprocess
import requests

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("StartMonitor")

# Импортируем необходимые модули
from keep_alive import keep_alive

# Запускаем keep_alive сервер
keep_alive()

# Путь к файлу бота
BOT_SCRIPT = 'main.py'

def monitor_bot():
    """
    Функция мониторинга бота, запускается в отдельном потоке.
    Проверяет, работает ли бот, и перезапускает его в случае сбоя.
    """
    bot_process = None
    check_interval = 60  # Проверка каждую минуту
    
    while True:
        try:
            # Проверяем, запущен ли бот
            if bot_process is None or bot_process.poll() is not None:
                if bot_process is not None:
                    logger.warning("Бот остановлен. Перезапуск...")
                else:
                    logger.info("Запуск бота...")
                
                # Запускаем бота
                if sys.platform == 'win32':
                    # Для Windows
                    bot_process = subprocess.Popen([sys.executable, BOT_SCRIPT],
                                                  creationflags=subprocess.CREATE_NEW_CONSOLE)
                else:
                    # Для Linux/Unix
                    bot_process = subprocess.Popen([sys.executable, BOT_SCRIPT])
                
                logger.info(f"Бот успешно запущен (PID: {bot_process.pid})")
            else:
                logger.info("Бот работает нормально")
            
            # Ждем до следующей проверки
            time.sleep(check_interval)
        
        except Exception as e:
            logger.error(f"Ошибка в мониторинге: {e}")
            time.sleep(check_interval)

def start_ping_service():
    """
    Запускает сервис для поддержания соединения.
    Периодически отправляет запросы на сервер keep_alive.
    """
    ping_interval = 5 * 60  # Ping каждые 5 минут
    
    while True:
        try:
            # Отправляем запрос на keep_alive сервер
            response = requests.get("http://localhost:8787/", timeout=5)
            if response.status_code == 200:
                logger.info("Ping успешно выполнен, сервер активен")
            else:
                logger.warning(f"Ping вернул код {response.status_code}")
        except Exception as e:
            logger.error(f"Ошибка при выполнении ping: {e}")
        
        # Ждем до следующего ping
        time.sleep(ping_interval)

if __name__ == "__main__":
    logger.info("=" * 50)
    logger.info("ЗАПУСК СИСТЕМЫ 24/7 ДЛЯ TELEGRAM БОТА")
    logger.info("=" * 50)
    
    # Запускаем мониторинг бота в отдельном потоке
    monitor_thread = threading.Thread(target=monitor_bot)
    monitor_thread.daemon = True
    monitor_thread.start()
    
    # Запускаем сервис пингов в отдельном потоке
    ping_thread = threading.Thread(target=start_ping_service)
    ping_thread.daemon = True
    ping_thread.start()
    
    # Главный поток просто работает в бесконечном цикле
    try:
        while True:
            # Отправляем сообщение в консоль каждые 30 минут
            logger.info("Система 24/7 активна и работает")
            time.sleep(30 * 60)
    except KeyboardInterrupt:
        logger.info("Система 24/7 остановлена пользователем")
        sys.exit(0)