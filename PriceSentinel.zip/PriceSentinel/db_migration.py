"""
Database migration script to add language column to users table.
"""

import sqlite3
import logging
import config

def add_language_column():
    """Add language column to users table if it doesn't exist"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    
    try:
        # Check if the column already exists
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'language' not in columns:
            logging.info("Adding language column to users table")
            cursor.execute("ALTER TABLE users ADD COLUMN language TEXT DEFAULT 'en'")
            conn.commit()
            logging.info("Language column added successfully")
        else:
            logging.info("Language column already exists")
            
    except sqlite3.Error as e:
        logging.error(f"Database migration error: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    add_language_column()