import logging
import requests
import socket
import whois
import time
from urllib.parse import urlparse

def normalize_url(url):
    """Normalize URL to ensure it has a scheme"""
    if not url.startswith(('http://', 'https://')):
        return 'http://' + url
    return url

def scan_site(url):
    """Basic scan function that returns status code and server info"""
    try:
        # Normalize URL
        url = normalize_url(url)
        
        # Perform request
        response = requests.get(url, timeout=10)
        
        # Get basic info
        status_code = response.status_code
        server = response.headers.get('Server', 'Unknown')
        content_type = response.headers.get('Content-Type', 'Unknown')
        
        # Prepare result
        result = (
            f"🔍 Basic Scan Results for {url}\n\n"
            f"✅ Status: {status_code}\n"
            f"🖥️ Server: {server}\n"
            f"📄 Content Type: {content_type}\n"
            f"\nTo get more detailed information, use /scan_site_pro"
        )
        
        return result
    except requests.exceptions.RequestException as e:
        logging.error(f"Error scanning {url}: {str(e)}")
        return f"❌ Error scanning {url}: {str(e)}"
    except Exception as e:
        logging.error(f"Unexpected error scanning {url}: {str(e)}")
        return f"❌ Unexpected error while scanning: {str(e)}"

def scan_site_pro(url):
    """Advanced scan that returns detailed information about a website"""
    try:
        # Normalize URL
        url = normalize_url(url)
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        
        # Basic request info
        start_time = time.time()
        response = requests.get(url, timeout=10)
        response_time = time.time() - start_time
        
        # DNS and IP information
        try:
            ip_address = socket.gethostbyname(domain)
        except:
            ip_address = "Could not resolve"
        
        # WHOIS information
        try:
            whois_info = whois.whois(domain)
            registrar = whois_info.registrar
            creation_date = whois_info.creation_date
            expiration_date = whois_info.expiration_date
            
            if isinstance(creation_date, list):
                creation_date = creation_date[0]
            if isinstance(expiration_date, list):
                expiration_date = expiration_date[0]
                
            creation_date_str = creation_date.strftime('%Y-%m-%d') if creation_date else "Unknown"
            expiration_date_str = expiration_date.strftime('%Y-%m-%d') if expiration_date else "Unknown"
        except:
            registrar = "Unknown"
            creation_date_str = "Unknown"
            expiration_date_str = "Unknown"
        
        # Headers analysis
        security_headers = {
            'Strict-Transport-Security': response.headers.get('Strict-Transport-Security', 'Not set'),
            'Content-Security-Policy': response.headers.get('Content-Security-Policy', 'Not set'),
            'X-XSS-Protection': response.headers.get('X-XSS-Protection', 'Not set'),
            'X-Content-Type-Options': response.headers.get('X-Content-Type-Options', 'Not set'),
            'X-Frame-Options': response.headers.get('X-Frame-Options', 'Not set')
        }
        
        # Prepare detailed result
        result = (
            f"🔍 PRO Scan Results for {url}\n\n"
            f"✅ Status Code: {response.status_code}\n"
            f"⏱️ Response Time: {response_time:.2f} seconds\n\n"
            f"🌐 Domain Information:\n"
            f"  • IP Address: {ip_address}\n"
            f"  • Registrar: {registrar}\n"
            f"  • Created: {creation_date_str}\n"
            f"  • Expires: {expiration_date_str}\n\n"
            f"🖥️ Server Information:\n"
            f"  • Server: {response.headers.get('Server', 'Unknown')}\n"
            f"  • Content Type: {response.headers.get('Content-Type', 'Unknown')}\n"
            f"  • Encoding: {response.encoding}\n\n"
            f"🔒 Security Headers:\n"
        )
        
        for header, value in security_headers.items():
            result += f"  • {header}: {value}\n"
        
        return result
    except requests.exceptions.RequestException as e:
        logging.error(f"Error scanning {url}: {str(e)}")
        return f"❌ Error scanning {url}: {str(e)}"
    except Exception as e:
        logging.error(f"Unexpected error scanning {url}: {str(e)}")
        return f"❌ Unexpected error while scanning: {str(e)}"
