"""
Web application and Telegram bot for website scanning services.
This is the main entry point for both the Flask web app and the Telegram bot.
"""

import logging
import os
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram import executor
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
import config
from handlers import register_handlers
from admin_handlers import register_admin_handlers
from middlewares.user_middleware import UserMiddleware
import database as db

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# ------------------------------
# Flask Web Application Setup
# ------------------------------
class Base(DeclarativeBase):
    pass

db_sql = SQLAlchemy(model_class=Base)

# Create the Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "secure_website_scanner_key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db_sql.init_app(app)

# Import routes after app is created to avoid circular imports
with app.app_context():
    # This will be used when running as a web application
    try:
        from routes import *
        
        # Create database tables
        import models
        db_sql.create_all()
        
        logging.info("Flask web application initialized successfully")
    except ImportError:
        logging.warning("Routes module not found - running as bot only")

# ------------------------------
# Telegram Bot Setup
# ------------------------------
# Initialize bot and dispatcher
bot = Bot(token=config.BOT_TOKEN)
storage = MemoryStorage()  # For FSM
dp = Dispatcher(bot, storage=storage)

# Setup middlewares
dp.middleware.setup(LoggingMiddleware())
dp.middleware.setup(UserMiddleware())

# Initialize database
# Import the database module to avoid confusion with db_sql
import database as db_module
db_module.create_db()

# Register message handlers
register_handlers(dp)

# Register admin handlers
register_admin_handlers(dp)

# Startup notification
async def on_startup(dp):
    """Send startup notification to admin"""
    try:
        await bot.send_message(
            config.ADMIN_ID,
            "🚀 Bot has been started!\n\n"
            "Use /admin to access the admin panel."
        )
        logging.info("Bot started successfully")
    except Exception as e:
        logging.error(f"Failed to notify admin: {e}")
        logging.info("Bot started but admin notification failed")

if __name__ == "__main__":
    # Import module to keep the bot active 24/7
    from keep_alive import keep_alive
    
    # Start web server to keep the bot running
    keep_alive()
    
    # Start the bot
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup)