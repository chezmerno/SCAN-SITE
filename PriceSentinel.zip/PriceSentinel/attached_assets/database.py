import sqlite3

def create_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users
                      (user_id INTEGER PRIMARY KEY, username TEXT, attempts INTEGER, subscription TEXT)''')
    conn.commit()
    conn.close()

def get_user(user_id):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user

def update_user(user_id, attempts, subscription):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("REPLACE INTO users (user_id, attempts, subscription) VALUES (?, ?, ?)",
                   (user_id, attempts, subscription))
    conn.commit()
    conn.close()