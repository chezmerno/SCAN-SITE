import requests

def scan_site(url):
    """Функция сканирования сайта (основная информация)"""
    try:
        response = requests.get(url)
        return f"Информация о сайте {url}: Статус код: {response.status_code}"
    except Exception as e:
        return f"Ошибка при сканировании: {str(e)}"

def scan_site_pro(url):
    """Функция PRO-сканирования (полная информация)"""
    # Можно добавить более подробную информацию о сайте
    try:
        response = requests.get(url)
        headers = response.headers
        return f"Полная информация о сайте {url}:\nСтатус код: {response.status_code}\nЗаголовки: {headers}"
    except Exception as e:
        return f"Ошибка при сканировании: {str(e)}"