from aiogram import Dispatcher, types
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from utils.scanner import scan_site, scan_site_pro
import config

async def cmd_start(message: types.Message):
    """Обработка команды /start"""
    await message.answer("ПРИВЕТ! ЭТО СКАНЕР БОТ SITE — @chezmernoscan_bot\n\n"
                         "Данный бот обладает способностью узнавать любую информацию о сайте.\n"
                         "Зависит от того: Бесплатно или PRO.\n\n"
                         "Следи за новостями: @chezmerno_news\nПриятного использования!")

async def cmd_scan_site(message: types.Message):
    """Обработка команды /scan_site"""
    await message.answer("Введите URL сайта для сканирования:")

async def cmd_scan_site_pro(message: types.Message):
    """Обработка команды /scan_site_pro"""
    await message.answer("Введите URL сайта для PRO-сканирования. Доступ только для подписчиков.")

def register_handlers(dp: Dispatcher):
    """Регистрация хэндлеров"""
    dp.register_message_handler(cmd_start, commands=["start"])
    dp.register_message_handler(cmd_scan_site, commands=["scan_site"])
    dp.register_message_handler(cmd_scan_site_pro, commands=["scan_site_pro"])