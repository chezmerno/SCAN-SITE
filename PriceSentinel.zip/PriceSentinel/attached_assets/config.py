# Ваш токен
BOT_TOKEN = '7579503505:AAHdsYRaUwuiWwbjKx_62AYrksfnJqDYAkA'
# Ваш ID администратора
ADMIN_ID = 7465790676  # Замените на ваш ID