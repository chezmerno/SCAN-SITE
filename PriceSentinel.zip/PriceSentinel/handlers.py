import logging
from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
import re
import config
import database as db
from utils.scanner import scan_site, scan_site_pro
from translations import get_message
from keyboards import (
    get_main_keyboard, get_admin_keyboard, get_cancel_keyboard,
    get_user_profile_keyboard, get_subscription_keyboard,
    get_back_to_main_keyboard, get_language_keyboard
)

# Define states for different operations
class ScanState(StatesGroup):
    waiting_for_url = State()
    waiting_for_pro_url = State()

# URL validation pattern
URL_PATTERN = re.compile(
    r'^(?:http|https)?://'  # http:// or https:// (optional)
    r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+(?:[A-Z]{2,6}\.?|[A-Z0-9-]{2,}\.?)|'  # domain
    r'localhost|'  # localhost
    r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|'  # or ipv4
    r'\[?[A-F0-9]*:[A-F0-9:]+\]?)'  # or ipv6
    r'(?::\d+)?'  # optional port
    r'(?:/?|[/?]\S+)$', re.IGNORECASE)

def is_valid_url(url):
    """Check if URL is valid"""
    return bool(URL_PATTERN.match(url))

async def cmd_start(message: types.Message):
    """Handle /start command"""
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name
    last_name = message.from_user.last_name
    
    # Register the user in the database
    db.register_user(user_id, username, first_name, last_name)
    
    # Get user's language
    language = db.get_user_language(user_id)
    
    # Prepare appropriate keyboard
    if user_id == config.ADMIN_ID:
        keyboard = get_admin_keyboard()
    else:
        keyboard = get_main_keyboard()
    
    # Welcome message using translation with markdown formatting
    await message.answer(
        get_message('start', language),
        reply_markup=keyboard,
        parse_mode="Markdown"
    )

async def cmd_help(message: types.Message):
    """Handle /help command"""
    user_id = message.from_user.id
    language = db.get_user_language(user_id)
    
    from keyboards import get_help_keyboard
    
    await message.answer(
        get_message('help', language),
        reply_markup=get_help_keyboard(language)
    )
    
async def cmd_language(message: types.Message):
    """Handle /language command to change language"""
    user_id = message.from_user.id
    language = db.get_user_language(user_id)
    
    await message.answer(
        get_message('language', language),
        reply_markup=get_language_keyboard()
    )

async def cmd_scan_site(message: types.Message, state: FSMContext):
    """Handle /scan_site command to start basic scanning"""
    user_id = message.from_user.id
    language = db.get_user_language(user_id)
    
    await message.answer(
        "🔍 " + get_message('scan_site', language),
        reply_markup=get_cancel_keyboard()
    )
    await ScanState.waiting_for_url.set()

async def cmd_scan_site_pro(message: types.Message, state: FSMContext, user_subscription=None):
    """Handle /scan_site_pro command to start PRO scanning"""
    user_id = message.from_user.id
    language = db.get_user_language(user_id)
    
    # Check subscription status
    if not user_subscription:
        user_subscription = db.check_subscription_status(user_id)
    
    # Only allow PRO users to proceed
    if user_subscription != config.SUB_PRO:
        subscription_keyboard = get_subscription_keyboard()
        await message.answer(
            "🔒 " + get_message('pro_access_required', language),
            reply_markup=subscription_keyboard
        )
        return
    
    await message.answer(
        "🔬 " + get_message('scan_site_pro', language),
        reply_markup=get_cancel_keyboard()
    )
    await ScanState.waiting_for_pro_url.set()

async def process_url_scan(message: types.Message, state: FSMContext):
    """Process URL for basic scanning"""
    user_id = message.from_user.id
    language = db.get_user_language(user_id)
    
    if message.text == "❌ Cancel":
        await state.finish()
        await message.answer(
            get_message('operation_cancelled', language),
            reply_markup=get_main_keyboard()
        )
        return
    
    url = message.text.strip()
    
    
    # Validate URL format
    if not is_valid_url(url):
        await message.answer(
            "❌ Invalid URL format. Please enter a valid website URL (e.g., example.com or https://example.com)",
            reply_markup=get_cancel_keyboard()
        )
        return
    
    # Check user attempts for free users
    user = db.get_user(user_id)
    if not user:
        await message.answer("Error: User not found. Please restart the bot with /start command.")
        await state.finish()
        return
    
    subscription = db.check_subscription_status(user_id)
    
    # Check remaining attempts for free users
    if subscription == config.SUB_FREE and user[4] <= 0:  # attempts index is 4
        await message.answer(
            "❌ You've used all your free scan attempts.\n\n"
            "Get a PRO subscription to continue scanning websites.",
            reply_markup=get_subscription_keyboard()
        )
        await state.finish()
        return
    
    # Send loading message
    loading_message = await message.answer("🔍 Scanning website, please wait...")
    
    try:
        # Perform scan
        scan_result = scan_site(url)
        
        # Record scan in history
        db.record_scan(user_id, url, config.SCAN_BASIC)
        
        # Update attempts for free users
        if subscription == config.SUB_FREE:
            attempts_left = db.decrement_user_attempts(user_id)
            scan_result += f"\n\n⚠️ You have {attempts_left} free scans remaining."
        
        # Send result
        await loading_message.delete()
        await message.answer(
            scan_result,
            disable_web_page_preview=True,
            reply_markup=get_main_keyboard()
        )
    except Exception as e:
        logging.error(f"Error during basic scan: {e}")
        await loading_message.delete()
        await message.answer(
            f"❌ Error during scanning: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    await state.finish()

async def process_pro_url_scan(message: types.Message, state: FSMContext):
    """Process URL for PRO scanning"""
    if message.text == "❌ Cancel":
        await state.finish()
        await message.answer(
            "Operation cancelled.",
            reply_markup=get_main_keyboard()
        )
        return
    
    url = message.text.strip()
    user_id = message.from_user.id
    
    # Validate URL format
    if not is_valid_url(url):
        await message.answer(
            "❌ Invalid URL format. Please enter a valid website URL (e.g., example.com or https://example.com)",
            reply_markup=get_cancel_keyboard()
        )
        return
    
    # Double-check subscription status
    subscription = db.check_subscription_status(user_id)
    if subscription != config.SUB_PRO:
        await message.answer(
            "❌ You need a PRO subscription to access this feature.",
            reply_markup=get_subscription_keyboard()
        )
        await state.finish()
        return
    
    # Send loading message (PRO scan takes longer)
    loading_message = await message.answer("🔬 Performing detailed PRO scan, please wait...")
    
    try:
        # Perform PRO scan
        scan_result = scan_site_pro(url)
        
        # Record scan in history
        db.record_scan(user_id, url, config.SCAN_PRO)
        
        # Send result
        await loading_message.delete()
        await message.answer(
            scan_result,
            disable_web_page_preview=True,
            reply_markup=get_main_keyboard()
        )
    except Exception as e:
        logging.error(f"Error during PRO scan: {e}")
        await loading_message.delete()
        await message.answer(
            f"❌ Error during PRO scanning: {str(e)}",
            reply_markup=get_main_keyboard()
        )
    
    await state.finish()

async def cmd_profile(message: types.Message):
    """Handle /profile command to show user profile"""
    user_id = message.from_user.id
    user = db.get_user(user_id)
    
    if not user:
        await message.answer("Error: User not found. Please restart the bot with /start command.")
        return
    
    user_id, username, first_name, last_name, attempts, subscription, sub_end_date, reg_date = user
    
    # Format subscription status
    sub_status = "Free"
    sub_info = f"You have {attempts} free scans remaining."
    is_pro = False
    
    if subscription == config.SUB_PRO:
        sub_status = "PRO"
        sub_info = "You have unlimited access to all scanning features."
        is_pro = True
        if sub_end_date:
            sub_info += f"\nYour PRO subscription expires on: {sub_end_date[:10]}"
    
    # Get scan history
    scans = db.get_user_scans(user_id, 5)
    scan_history = ""
    if scans:
        scan_history = "\n\n📜 Recent Scans:\n"
        for url, scan_type, scan_date in scans:
            scan_type_display = "PRO" if scan_type == config.SCAN_PRO else "Basic"
            scan_history += f"• {url} - {scan_type_display} - {scan_date[:10]}\n"
    else:
        scan_history = "\n\nNo scan history yet."
    
    # Get user's language
    language = db.get_user_language(user_id)
    
    # Get subscription text from translations
    sub_text = get_message(f'subscription.{subscription.lower()}', language)
    
    # Build profile message using the translation
    profile_msg = get_message('profile', language, 
                             user_id=user_id,
                             username=username or 'Not set',
                             first_name=first_name or 'Not set',
                             last_name=last_name or '',
                             subscription=sub_status,
                             subscription_ru=sub_text,
                             attempts=attempts,
                             language=get_message('language_names.en', language),
                             language_ru=get_message('language_names.ru', language),
                             reg_date=reg_date[:10] if reg_date else 'Unknown')
    
    # Add subscription info and scan history
    profile_msg += f"\n\n{sub_info}{scan_history}"
    
    # Send profile with appropriate keyboard
    await message.answer(
        profile_msg,
        parse_mode="Markdown",
        reply_markup=get_user_profile_keyboard(is_pro)
    )

async def handle_text_messages(message: types.Message, state: FSMContext):
    """Handle text messages that are not commands"""
    text = message.text
    user_id = message.from_user.id
    language = db.get_user_language(user_id)
    from translations import get_message
    
    # Get translated button texts
    basic_scan_btn = "🔍 " + get_message('main_menu.basic_scan', language)
    pro_scan_btn = "🔬 " + get_message('main_menu.pro_scan', language)
    profile_btn = "👤 " + get_message('main_menu.profile', language)
    help_btn = "❓ " + get_message('main_menu.help', language)
    language_btn = "🌐 " + get_message('main_menu.language', language)
    admin_btn = "👑 " + get_message('main_menu.admin', language)
    
    if text == basic_scan_btn or text == "🔍 Basic Scan":
        await cmd_scan_site(message, state)
    elif text == pro_scan_btn or text == "🔬 PRO Scan":
        await cmd_scan_site_pro(message, state)
    elif text == profile_btn or text == "👤 My Profile":
        await cmd_profile(message)
    elif text == help_btn or text == "❓ Help":
        await cmd_help(message)
    elif text == language_btn or text == "🌐 Language" or text.lower().startswith("language "):
        await cmd_language(message)
    elif text == admin_btn or text == "👑 Admin Panel":
        # Handle admin panel access
        if user_id == config.ADMIN_ID:
            await message.answer(
                get_message('admin.welcome', language, default="Welcome to Admin Panel!"),
                reply_markup=get_admin_panel_keyboard()
            )
        else:
            await message.answer(get_message('admin.no_rights', language, default="You don't have admin rights."))

async def handle_callback_queries(callback_query: types.CallbackQuery, state: FSMContext):
    """Handle callback queries from inline keyboards"""
    callback_data = callback_query.data
    user_id = callback_query.from_user.id
    
    # Handle language selection
    if callback_data.startswith("language_"):
        lang_code = callback_data.split("_")[1]
        if lang_code in ["en", "ru"]:
            db.set_user_language(user_id, lang_code)
            await callback_query.message.edit_text(
                get_message('language_set', lang_code),
                reply_markup=get_back_to_main_keyboard()
            )
            return
    
    if callback_data == "back_to_main":
        # Return to main menu
        language = db.get_user_language(user_id)
        
        if user_id == config.ADMIN_ID:
            reply_markup = get_admin_keyboard()
        else:
            reply_markup = get_main_keyboard(language)
        
        await callback_query.message.edit_text(
            get_message('main_menu.title', language),
            reply_markup=None
        )
        
        await callback_query.message.answer(
            get_message('main_menu.prompt', language),
            reply_markup=reply_markup
        )
    
    elif callback_data == "subscribe_pro":
        # Show subscription options
        await callback_query.message.edit_text(
            "💎 *PRO Subscription*\n\n"
            "To get a PRO subscription, please contact the bot administrator.\n\n"
            "Benefits of PRO:\n"
            "• Unlimited website scans\n"
            "• Detailed technical information\n"
            "• Security header analysis\n"
            "• Domain registration details\n",
            parse_mode="Markdown",
            reply_markup=get_back_to_main_keyboard()
        )
    
    elif callback_data == "scan_history":
        # Show detailed scan history
        scans = db.get_user_scans(user_id, 10)
        
        if not scans:
            await callback_query.message.edit_text(
                "You haven't performed any scans yet.",
                reply_markup=get_back_to_main_keyboard()
            )
            return
        
        history_text = "📜 *Your Scan History*\n\n"
        for i, (url, scan_type, scan_date) in enumerate(scans, 1):
            scan_type_display = "PRO" if scan_type == config.SCAN_PRO else "Basic"
            history_text += f"{i}. {url}\n   Type: {scan_type_display}\n   Date: {scan_date}\n\n"
        
        await callback_query.message.edit_text(
            history_text,
            parse_mode="Markdown",
            reply_markup=get_back_to_main_keyboard()
        )
    
    elif callback_data == "reset_attempts":
        # Reset user's free attempts (for testing)
        subscription = db.check_subscription_status(user_id)
        
        if subscription == config.SUB_PRO:
            await callback_query.answer("PRO users have unlimited attempts.", show_alert=True)
            return
        
        # Reset attempts for free users
        db.reset_user_attempts(user_id)
        
        await callback_query.message.edit_text(
            "✅ Your free attempts have been reset.",
            reply_markup=get_back_to_main_keyboard()
        )
    
    await callback_query.answer()

def register_handlers(dp: Dispatcher):
    """Register all message handlers"""
    # Command handlers
    dp.register_message_handler(cmd_start, commands=["start"])
    dp.register_message_handler(cmd_help, commands=["help"])
    dp.register_message_handler(cmd_language, commands=["language"])
    dp.register_message_handler(cmd_scan_site, commands=["scan_site"], state=None)
    dp.register_message_handler(cmd_scan_site_pro, commands=["scan_site_pro"], state=None)
    dp.register_message_handler(cmd_profile, commands=["profile"])
    
    # State handlers
    dp.register_message_handler(process_url_scan, state=ScanState.waiting_for_url)
    dp.register_message_handler(process_pro_url_scan, state=ScanState.waiting_for_pro_url)
    
    # Text message handlers
    dp.register_message_handler(handle_text_messages, lambda msg: msg.text, state=None)
    
    # Callback query handlers
    dp.register_callback_query_handler(handle_callback_queries, lambda c: not c.data.startswith("admin_"))
