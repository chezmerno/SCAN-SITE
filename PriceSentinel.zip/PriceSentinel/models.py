from datetime import datetime
from app import db
from flask_login import UserMixin

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    telegram_id = db.Column(db.Integer, unique=True)
    username = db.Column(db.String(64), nullable=True)
    first_name = db.Column(db.String(64), nullable=True)
    last_name = db.Column(db.String(64), nullable=True)
    password_hash = db.Column(db.String(256), nullable=True)
    attempts = db.Column(db.Integer, default=5)
    subscription = db.Column(db.String(10), default="free")
    subscription_end_date = db.Column(db.DateTime, nullable=True)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)
    language = db.Column(db.String(2), default="en")  # Added language preference
    
    # Relationship with scan history
    scans = db.relationship('ScanHistory', backref='user', lazy='dynamic')
    
    def get_id(self):
        return str(self.id)
    
    def is_pro(self):
        """Check if user has PRO subscription"""
        if self.subscription != "pro":
            return False
            
        if not self.subscription_end_date:
            return True
            
        return self.subscription_end_date > datetime.utcnow()
    
    def __repr__(self):
        return f'<User {self.username or self.telegram_id}>'


class ScanHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    url = db.Column(db.String(256), nullable=False)
    scan_type = db.Column(db.String(10), nullable=False)
    scan_date = db.Column(db.DateTime, default=datetime.utcnow)
    status_code = db.Column(db.Integer, nullable=True)
    server_info = db.Column(db.String(256), nullable=True)
    content_type = db.Column(db.String(100), nullable=True)
    
    def __repr__(self):
        return f'<Scan {self.url} by User {self.user_id} at {self.scan_date}>'