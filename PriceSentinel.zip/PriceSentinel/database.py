import sqlite3
import logging
import os
from datetime import datetime, timedelta
import config

# Определяем, используем ли PostgreSQL или SQLite
USE_POSTGRES = os.environ.get('DATABASE_URL') is not None

if USE_POSTGRES:
    import psycopg2
    import psycopg2.extras

def get_connection():
    """Создает соединение с базой данных в зависимости от настроек"""
    if USE_POSTGRES:
        # Используем PostgreSQL
        conn = psycopg2.connect(os.environ.get('DATABASE_URL'))
        conn.autocommit = True  # Автоматический коммит для PostgreSQL
        return conn
    else:
        # Используем SQLite
        return sqlite3.connect(config.DB_NAME)

def create_db():
    """Create the database and necessary tables if they don't exist"""
    conn = get_connection()
    cursor = conn.cursor()
    
    if USE_POSTGRES:
        # PostgreSQL SQL-синтаксис
        try:
            # Create users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users
                (user_id INTEGER PRIMARY KEY, 
                 username TEXT, 
                 first_name TEXT,
                 last_name TEXT,
                 attempts INTEGER DEFAULT 0,
                 subscription TEXT DEFAULT 'free',
                 subscription_end_date TIMESTAMP DEFAULT NULL,
                 registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 language TEXT DEFAULT 'ru')
            ''')
            
            # Create scan_history table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scan_history
                (id SERIAL PRIMARY KEY,
                 user_id INTEGER,
                 url TEXT,
                 scan_type TEXT,
                 scan_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                 FOREIGN KEY (user_id) REFERENCES users(user_id))
            ''')
        except Exception as e:
            logging.error(f"Ошибка создания таблиц PostgreSQL: {e}")
    else:
        # SQLite SQL-синтаксис
        try:
            # Create users table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users
                (user_id INTEGER PRIMARY KEY, 
                 username TEXT, 
                 first_name TEXT,
                 last_name TEXT,
                 attempts INTEGER DEFAULT 0,
                 subscription TEXT DEFAULT 'free',
                 subscription_end_date TEXT DEFAULT NULL,
                 registration_date TEXT DEFAULT CURRENT_TIMESTAMP,
                 language TEXT DEFAULT 'ru')
            ''')
            
            # Create scan_history table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scan_history
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 user_id INTEGER,
                 url TEXT,
                 scan_type TEXT,
                 scan_date TEXT DEFAULT CURRENT_TIMESTAMP,
                 FOREIGN KEY (user_id) REFERENCES users(user_id))
            ''')
            conn.commit()
        except Exception as e:
            logging.error(f"Ошибка создания таблиц SQLite: {e}")
            
    if not USE_POSTGRES:
        conn.commit()
    conn.close()
    logging.info("База данных успешно инициализирована")

def get_user(user_id):
    """Get user information by user_id"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    user = cursor.fetchone()
    conn.close()
    return user

def register_user(user_id, username=None, first_name=None, last_name=None, language='en'):
    """Register a new user or update existing user information"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    
    # Check if user exists
    cursor.execute("SELECT user_id FROM users WHERE user_id=?", (user_id,))
    existing_user = cursor.fetchone()
    
    if existing_user:
        # Update existing user
        cursor.execute("""UPDATE users SET 
                          username=COALESCE(?, username),
                          first_name=COALESCE(?, first_name),
                          last_name=COALESCE(?, last_name)
                          WHERE user_id=?""", 
                       (username, first_name, last_name, user_id))
    else:
        # Create new user with default free attempts
        cursor.execute("""INSERT INTO users 
                          (user_id, username, first_name, last_name, attempts, subscription, language) 
                          VALUES (?, ?, ?, ?, ?, ?, ?)""",
                       (user_id, username, first_name, last_name, config.FREE_ATTEMPTS, config.SUB_FREE, language))
    
    conn.commit()
    conn.close()
    return get_user(user_id)

def update_user_attempts(user_id, attempts):
    """Update user's remaining scan attempts"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET attempts=? WHERE user_id=?", (attempts, user_id))
    conn.commit()
    conn.close()

def decrement_user_attempts(user_id):
    """Decrease user's attempts by 1 and return the updated value"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET attempts=attempts-1 WHERE user_id=? AND attempts>0", (user_id,))
    cursor.execute("SELECT attempts FROM users WHERE user_id=?", (user_id,))
    attempts = cursor.fetchone()[0]
    conn.commit()
    conn.close()
    return attempts

def update_user_subscription(user_id, subscription, days=None):
    """Update user's subscription status"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    
    end_date = None
    if days:
        end_date = (datetime.now() + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
    
    cursor.execute("""UPDATE users SET 
                      subscription=?, 
                      subscription_end_date=? 
                      WHERE user_id=?""", 
                   (subscription, end_date, user_id))
    
    # Add attempts for PRO users
    if subscription == config.SUB_PRO:
        cursor.execute("UPDATE users SET attempts=999999 WHERE user_id=?", (user_id,))
    
    conn.commit()
    conn.close()

def reset_user_attempts(user_id, attempts=config.FREE_ATTEMPTS):
    """Reset user's attempts to default value"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET attempts=? WHERE user_id=?", (attempts, user_id))
    conn.commit()
    conn.close()

def record_scan(user_id, url, scan_type):
    """Record a scan operation in the history"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""INSERT INTO scan_history 
                      (user_id, url, scan_type) 
                      VALUES (?, ?, ?)""", 
                   (user_id, url, scan_type))
    conn.commit()
    conn.close()

def get_user_scans(user_id, limit=10):
    """Get the last scans for a user"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""SELECT url, scan_type, scan_date 
                      FROM scan_history 
                      WHERE user_id=? 
                      ORDER BY scan_date DESC 
                      LIMIT ?""", 
                   (user_id, limit))
    scans = cursor.fetchall()
    conn.close()
    return scans

def get_all_users(limit=100):
    """Get all registered users with limit"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""SELECT user_id, username, first_name, last_name, 
                      attempts, subscription, subscription_end_date 
                      FROM users 
                      ORDER BY registration_date DESC 
                      LIMIT ?""", 
                   (limit,))
    users = cursor.fetchall()
    conn.close()
    return users

def check_subscription_status(user_id):
    """Check if user's subscription is still valid"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""SELECT subscription, subscription_end_date 
                      FROM users 
                      WHERE user_id=?""", 
                   (user_id,))
    user_data = cursor.fetchone()
    conn.close()
    
    if not user_data:
        return config.SUB_FREE
    
    subscription, end_date = user_data
    
    # If free subscription or no end date, return as is
    if subscription == config.SUB_FREE or not end_date:
        return subscription
    
    # Check if PRO subscription has expired
    if subscription == config.SUB_PRO and end_date:
        end_datetime = datetime.strptime(end_date, '%Y-%m-%d %H:%M:%S')
        if end_datetime < datetime.now():
            # Subscription expired, revert to free
            update_user_subscription(user_id, config.SUB_FREE)
            reset_user_attempts(user_id)
            return config.SUB_FREE
    
    return subscription

def get_user_language(user_id):
    """Get user's language preference"""
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT language FROM users WHERE user_id=?", (user_id,))
    result = cursor.fetchone()
    conn.close()
    
    if result:
        return result[0]
    return 'en'  # Default to English

def set_user_language(user_id, language):
    """Set user's language preference"""
    if language not in ['en', 'ru']:
        language = 'en'  # Only allow supported languages
        
    conn = sqlite3.connect(config.DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET language=? WHERE user_id=?", (language, user_id))
    conn.commit()
    conn.close()
    return language
