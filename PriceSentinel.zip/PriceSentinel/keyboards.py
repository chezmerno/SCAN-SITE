from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton

def get_main_keyboard(language='en'):
    """Create main keyboard with primary bot functions"""
    from translations import get_message
    
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("🔍 " + get_message('main_menu.basic_scan', language)))
    keyboard.add(KeyboardButton("🔬 " + get_message('main_menu.pro_scan', language)))
    keyboard.add(KeyboardButton("👤 " + get_message('main_menu.profile', language)), 
                 KeyboardButton("❓ " + get_message('main_menu.help', language)))
    keyboard.add(KeyboardButton("🌐 " + get_message('main_menu.language', language)))
    return keyboard

def get_admin_keyboard(language='en'):
    """Create admin keyboard with additional functions"""
    from translations import get_message
    
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("🔍 " + get_message('main_menu.basic_scan', language)))
    keyboard.add(KeyboardButton("🔬 " + get_message('main_menu.pro_scan', language)))
    keyboard.add(KeyboardButton("👤 " + get_message('main_menu.profile', language)), 
                 KeyboardButton("❓ " + get_message('main_menu.help', language)))
    keyboard.add(KeyboardButton("👑 " + get_message('main_menu.admin', language)),
                 KeyboardButton("🌐 " + get_message('main_menu.language', language)))
    return keyboard

def get_cancel_keyboard():
    """Create a simple cancel keyboard"""
    keyboard = ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add(KeyboardButton("❌ Cancel"))
    return keyboard

def get_subscription_keyboard():
    """Create keyboard for subscription options"""
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("💎 Get PRO Subscription (30 days)", callback_data="subscribe_pro"))
    keyboard.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_main"))
    return keyboard

def get_user_profile_keyboard(is_pro=False):
    """Create keyboard for user profile options"""
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("📊 My Scan History", callback_data="scan_history"))
    
    if not is_pro:
        keyboard.add(InlineKeyboardButton("💎 Get PRO Access", callback_data="subscribe_pro"))
    else:
        keyboard.add(InlineKeyboardButton("⭐ PRO Status Active", callback_data="pro_info"))
    
    keyboard.add(InlineKeyboardButton("🔄 Reset Free Attempts", callback_data="reset_attempts"))
    return keyboard

def get_admin_panel_keyboard(language='en'):
    """Create admin panel keyboard with language support"""
    from translations import get_message
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("👥 " + get_message('admin_panel.user_list', language, default="User List"), 
                 callback_data="admin_user_list"))
    keyboard.add(InlineKeyboardButton("📊 " + get_message('admin_panel.stats', language, default="Statistics"), 
                 callback_data="admin_stats"))
    keyboard.add(InlineKeyboardButton("💎 " + get_message('admin_panel.grant_pro', language, default="Grant PRO to User"), 
                 callback_data="admin_grant_pro"))
    keyboard.add(InlineKeyboardButton("🔙 " + get_message('admin_panel.back', language, default="Back"), 
                 callback_data="back_to_main"))
    return keyboard

def get_back_to_main_keyboard():
    """Simple back button keyboard"""
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton("🔙 Back to Main Menu", callback_data="back_to_main"))
    return keyboard

def get_language_keyboard():
    """Create keyboard for language selection"""
    keyboard = InlineKeyboardMarkup()
    keyboard.add(
        InlineKeyboardButton("🇬🇧 English", callback_data="language_en"),
        InlineKeyboardButton("🇷🇺 Русский", callback_data="language_ru")
    )
    keyboard.add(InlineKeyboardButton("🔙 Back", callback_data="back_to_main"))
    return keyboard

def get_help_keyboard(language='en'):
    """Create keyboard for help command with contact and channel links"""
    from translations import get_message
    
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton(
        get_message('help_keyboard.contact_admin', language, default="📞 Contact Admin"), 
        url="https://t.me/portsell"
    ))
    keyboard.add(InlineKeyboardButton(
        get_message('help_keyboard.our_channel', language, default="📢 Our Channel"), 
        url="https://t.me/chezmerno_newz"
    ))
    keyboard.add(InlineKeyboardButton(
        get_message('help_keyboard.back', language, default="🔙 Back"), 
        callback_data="back_to_main"
    ))
    return keyboard
