import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


db = SQLAlchemy(model_class=Base)
# create the app
app = Flask(__name__)
# setup a secret key, required by sessions
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")
# configure the database, relative to the app instance folder
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
# initialize the app with the extension, flask-sqlalchemy >= 3.0.x
db.init_app(app)

with app.app_context():
    # Make sure to import the models here or their tables won't be created
    import models  # noqa: F401

    db.create_all()

def create_admin():
    """Create admin user if it doesn't exist"""
    from models import User
    from werkzeug.security import generate_password_hash
    import config
    
    with app.app_context():
        # Check if admin exists
        admin = User.query.filter_by(is_admin=True).first()
        if not admin:
            # Create admin user
            admin = User(
                telegram_id=config.ADMIN_ID,
                username="admin",
                first_name="Admin",
                is_admin=True,
                attempts=999,
                subscription="pro",
                password_hash=generate_password_hash("admin")  # Default password, should be changed
            )
            db.session.add(admin)
            db.session.commit()
            print("Admin user created")
        else:
            print("Admin user already exists")