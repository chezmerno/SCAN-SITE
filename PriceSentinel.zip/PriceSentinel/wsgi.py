"""
WSGI entry point for the Flask application.
This file is used by Gunicorn.
"""

from simple_web import app

# This is what Gunicorn will look for
application = app

# Make it runnable standalone as well
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)