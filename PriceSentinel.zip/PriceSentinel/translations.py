"""
Translations for the Website Scanner Bot.
This file contains all text messages in supported languages.
"""

# Dictionary of translations
MESSAGES = {
    # Start command
    'start': {
        'en': "🌟 *Welcome to the Advanced Website Scanner Bot!* 🌟\n\n"
              "✨ Unlock the power of website analysis with our advanced scanning tools! ✨\n\n"
              "📊 *What You Can Do:*\n"
              "• 🔍 Use /scan_site for basic website analysis\n"
              "• 🔬 Use /scan_site_pro for detailed PRO scanning\n"
              "• 👤 Use /profile to manage your account\n"
              "• ❓ Use /help for assistance\n"
              "• 🌐 Use /language to switch languages\n\n"
              "Get started by clicking one of the buttons below! 👇",
        'ru': "🌟 *Добро пожаловать в Продвинутый Сканер Сайтов!* 🌟\n\n"
              "✨ Откройте для себя возможности нашего инструмента для анализа веб-сайтов! ✨\n\n"
              "📊 *Возможности:*\n"
              "• 🔍 Используйте /scan_site для базового анализа\n"
              "• 🔬 Используйте /scan_site_pro для подробного PRO сканирования\n"
              "• 👤 Используйте /profile для управления аккаунтом\n"
              "• ❓ Используйте /help для получения помощи\n"
              "• 🌐 Используйте /language для смены языка\n\n"
              "Начните работу, нажав одну из кнопок ниже! 👇"
    },
    
    # Help command
    'help': {
        'en': "🔍 Website Scanner Bot Help:\n\n"
              "/start - Start the bot\n"
              "/scan_site - Perform a basic website scan\n"
              "/scan_site_pro - Perform a detailed website scan (PRO)\n"
              "/profile - View your profile\n"
              "/language - Change bot language\n"
              "/help - Show this help message",
        'ru': "🔍 Справка бота Сканер Сайтов:\n\n"
              "/start - Запустить бота\n"
              "/scan_site - Выполнить базовое сканирование сайта\n"
              "/scan_site_pro - Выполнить детальное сканирование сайта (PRO)\n"
              "/profile - Просмотреть ваш профиль\n"
              "/language - Изменить язык бота\n"
              "/help - Показать это сообщение"
    },
    
    # Profile command
    'profile': {
        'en': "👤 Your Profile:\n\n"
              "User ID: {user_id}\n"
              "Username: {username}\n"
              "Subscription: {subscription}\n"
              "Remaining scans: {attempts}\n"
              "Language: {language}",
        'ru': "👤 Ваш Профиль:\n\n"
              "ID пользователя: {user_id}\n"
              "Имя пользователя: {username}\n"
              "Подписка: {subscription_ru}\n"
              "Осталось сканирований: {attempts}\n"
              "Язык: {language_ru}"
    },
    
    # Language command
    'language': {
        'en': "🌐 Select your preferred language:",
        'ru': "🌐 Выберите предпочитаемый язык:"
    },
    
    # Language set confirmation
    'language_set': {
        'en': "✅ Language has been set to English.",
        'ru': "✅ Язык установлен на русский."
    },
    
    # Scan site command
    'scan_site': {
        'en': "Please enter a website URL to scan:",
        'ru': "Пожалуйста, введите URL сайта для сканирования:"
    },
    
    # Scan site pro command
    'scan_site_pro': {
        'en': "Please enter a website URL for detailed PRO scanning:",
        'ru': "Пожалуйста, введите URL сайта для детального PRO сканирования:"
    },
    
    # No attempts left
    'no_attempts': {
        'en': "❌ You have no scan attempts left. Get a PRO subscription for unlimited scans.",
        'ru': "❌ У вас не осталось попыток сканирования. Приобретите PRO подписку для безлимитного сканирования."
    },
    
    # Invalid URL
    'invalid_url': {
        'en': "❌ Invalid URL format. Please enter a valid website URL.",
        'ru': "❌ Неверный формат URL. Пожалуйста, введите корректный URL сайта."
    },
    
    # Scanning in progress
    'scanning': {
        'en': "🔍 Scanning website... Please wait.",
        'ru': "🔍 Сканирование сайта... Пожалуйста, подождите."
    },
    
    # Basic scan result
    'scan_result': {
        'en': "📊 Scan Results for {url}:\n\n"
              "Status: {status_code}\n"
              "Server: {server}\n"
              "Content-Type: {content_type}\n"
              "Attempts left: {attempts}",
        'ru': "📊 Результаты сканирования для {url}:\n\n"
              "Статус: {status_code}\n"
              "Сервер: {server}\n"
              "Тип контента: {content_type}\n"
              "Осталось попыток: {attempts}"
    },
    
    # Pro scan result
    'scan_pro_result': {
        'en': "📈 PRO Scan Results for {url}:\n\n"
              "Status: {status_code}\n"
              "Server: {server}\n"
              "Content-Type: {content_type}\n"
              "Redirect URL: {redirect_url}\n"
              "Response Time: {response_time}ms\n"
              "SSL Secure: {ssl_secure}\n"
              "Headers: {headers}\n"
              "Cookies: {cookies}",
        'ru': "📈 PRO Результаты сканирования для {url}:\n\n"
              "Статус: {status_code}\n"
              "Сервер: {server}\n"
              "Тип контента: {content_type}\n"
              "URL перенаправления: {redirect_url}\n"
              "Время ответа: {response_time}мс\n"
              "SSL защита: {ssl_secure}\n"
              "Заголовки: {headers}\n"
              "Куки: {cookies}"
    },
    
    # Scan error
    'scan_error': {
        'en': "❌ Error scanning website: {error}",
        'ru': "❌ Ошибка при сканировании сайта: {error}"
    },
    
    # Subscription strings
    'subscription': {
        'free': {
            'en': "Free",
            'ru': "Бесплатная"
        },
        'pro': {
            'en': "PRO",
            'ru': "PRO"
        }
    },
    
    # Language names
    'language_names': {
        'en': {
            'en': "English",
            'ru': "Английский"
        },
        'ru': {
            'en': "Russian",
            'ru': "Русский"
        }
    },
    
    # Main menu buttons
    'main_menu': {
        'basic_scan': {
            'en': "Basic Scan",
            'ru': "Базовое сканирование"
        },
        'pro_scan': {
            'en': "PRO Scan",
            'ru': "PRO сканирование"
        },
        'profile': {
            'en': "My Profile",
            'ru': "Мой профиль"
        },
        'help': {
            'en': "Help",
            'ru': "Помощь"
        },
        'language': {
            'en': "Language",
            'ru': "Язык"
        },
        'admin': {
            'en': "Admin Panel",
            'ru': "Админ панель"
        },
        'title': {
            'en': "Main Menu",
            'ru': "Главное меню"
        },
        'prompt': {
            'en': "What would you like to do?",
            'ru': "Что бы вы хотели сделать?"
        }
    },
    
    # Admin panel messages
    'admin': {
        'welcome': {
            'en': "👑 Welcome to Admin Panel!",
            'ru': "👑 Добро пожаловать в Панель администратора!"
        },
        'no_rights': {
            'en': "⛔ You don't have admin rights.",
            'ru': "⛔ У вас нет прав администратора."
        },
        'users_count': {
            'en': "👥 Total users: {users_count}",
            'ru': "👥 Всего пользователей: {users_count}"
        },
        'grant_pro': {
            'en': "💎 Grant PRO access",
            'ru': "💎 Выдать PRO доступ"
        },
        'user_id_prompt': {
            'en': "Enter user ID to grant PRO access:",
            'ru': "Введите ID пользователя для выдачи PRO доступа:"
        },
        'user_not_found': {
            'en': "⚠️ User not found!",
            'ru': "⚠️ Пользователь не найден!"
        },
        'days_prompt': {
            'en': "Enter number of days for PRO access:",
            'ru': "Введите количество дней для PRO доступа:"
        },
        'pro_granted': {
            'en': "✅ PRO access granted to user {user_id} for {days} days.",
            'ru': "✅ PRO доступ выдан пользователю {user_id} на {days} дней."
        },
        'user_stats': {
            'en': "User ID: {user_id}\nUsername: {username}\nAttempts: {attempts}\nSubscription: {subscription}",
            'ru': "ID пользователя: {user_id}\nИмя пользователя: {username}\nПопыток: {attempts}\nПодписка: {subscription}"
        }
    },
    
    # Admin panel buttons
    'admin_panel': {
        'user_list': {
            'en': "User List",
            'ru': "Список пользователей"
        },
        'stats': {
            'en': "Statistics",
            'ru': "Статистика"
        },
        'grant_pro': {
            'en': "Grant PRO to User",
            'ru': "Выдать PRO доступ"
        },
        'back': {
            'en': "Back",
            'ru': "Назад"
        }
    },
    
    # Help keyboard buttons
    'help_keyboard': {
        'contact_admin': {
            'en': "📞 Contact Admin",
            'ru': "📞 Связь с администратором"
        },
        'our_channel': {
            'en': "📢 Our Channel",
            'ru': "📢 Наш канал"
        },
        'back': {
            'en': "🔙 Back",
            'ru': "🔙 Назад"
        }
    },
    
    # Operation cancelled
    'cancelled': {
        'en': "❌ Operation cancelled.",
        'ru': "❌ Операция отменена."
    },
    
    # Unknown command
    'unknown_command': {
        'en': "❓ Unknown command. Use /help to see available commands.",
        'ru': "❓ Неизвестная команда. Используйте /help для просмотра доступных команд."
    },
    
    # Invalid input
    'invalid_input': {
        'en': "❌ Invalid input. Please enter a valid {type}.",
        'ru': "❌ Неверный ввод. Пожалуйста, введите корректный {type}."
    },
    
    # Pro granted notification
    'pro_granted_notification': {
        'en': "*Congratulations!* 🎉\n\nYou've been granted *{days} days* of PRO access by an administrator.\n\nEnjoy advanced scanning features and unlimited scans!",
        'ru': "*Поздравляем!* 🎉\n\nАдминистратор предоставил вам *PRO доступ на {days} дней*.\n\nНаслаждайтесь расширенными возможностями сканирования и безлимитными проверками!"
    },
    
    # Admin specific messages
    'admin': {
        # Admin user not found
        'user_not_found': {
            'en': "❌ User with this ID was not found in the database.",
            'ru': "❌ Пользователь с этим ID не найден в базе данных."
        },
        # User statistics for admin
        'user_stats': {
            'en': "📊 *User Information*\n\n👤 User ID: `{user_id}`\n👤 Username: {username}\n🔢 Attempts: {attempts}\n💎 Subscription: {subscription}",
            'ru': "📊 *Информация о пользователе*\n\n👤 ID пользователя: `{user_id}`\n👤 Имя: {username}\n🔢 Попыток: {attempts}\n💎 Подписка: {subscription}"
        },
        # Days prompt for admin
        'days_prompt': {
            'en': "⏱️ *How many days of PRO access would you like to grant?*\n\nPlease enter a number (e.g., 30, 60, 90).",
            'ru': "⏱️ *На сколько дней вы хотите предоставить PRO доступ?*\n\nВведите число (например, 30, 60, 90)."
        },
        # Pro granted confirmation for admin
        'pro_granted': {
            'en': "✅ Successfully granted *{days} days* of PRO access to user ID `{user_id}`.\n\nThe user has been notified.",
            'ru': "✅ Успешно предоставлен *PRO доступ на {days} дней* пользователю с ID `{user_id}`.\n\nПользователь уведомлен."
        }
    }
}

def get_message(message_key, language='en', **kwargs):
    """
    Get a message in the specified language with optional formatting parameters
    
    Args:
        message_key (str): The key to look up in the MESSAGES dictionary
        language (str): The language code ('en' or 'ru')
        **kwargs: Optional parameters for string formatting
        
    Returns:
        str: The translated message, with formatting applied if kwargs provided
    """
    # Default to English if language not supported
    if language not in ['en', 'ru']:
        language = 'en'
        
    # If message_key is a nested dictionary (e.g., 'subscription.free')
    if '.' in message_key:
        parts = message_key.split('.')
        message = MESSAGES
        for part in parts:
            if part in message:
                message = message[part]
            else:
                return f"Missing translation: {message_key}"
        
        if isinstance(message, dict) and language in message:
            result = message[language]
        else:
            return f"Missing translation: {message_key}"
    else:
        # Simple top-level key
        if message_key not in MESSAGES:
            return f"Missing translation: {message_key}"
            
        message_dict = MESSAGES[message_key]
        result = message_dict.get(language, message_dict.get('en', f"Missing translation: {message_key}"))
    
    # Apply formatting if kwargs provided
    if kwargs:
        try:
            return result.format(**kwargs)
        except KeyError as e:
            return f"Format error in {message_key}: {e}"
    
    return result