import logging
from aiogram import types
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
from datetime import datetime
import database as db
import config

class UserMiddleware(BaseMiddleware):
    """Middleware for tracking and managing users"""
    
    async def on_pre_process_message(self, message: types.Message, data: dict):
        """Process user before handling the message"""
        # Skip middleware for messages without text
        if not message or not message.from_user:
            return
        
        user_id = message.from_user.id
        username = message.from_user.username
        first_name = message.from_user.first_name
        last_name = message.from_user.last_name
        
        # Register or update user info
        db.register_user(user_id, username, first_name, last_name)
        
        # Check subscription status
        subscription = db.check_subscription_status(user_id)
        
        # Store user data for handlers
        data['user_subscription'] = subscription
        
        # Log user activity
        logging.info(f"User {user_id} ({username}) activity: {message.text} [Subscription: {subscription}]")
    
    async def on_pre_process_callback_query(self, query: types.CallbackQuery, data: dict):
        """Process user before handling the callback query"""
        if not query or not query.from_user:
            return
        
        user_id = query.from_user.id
        username = query.from_user.username
        first_name = query.from_user.first_name
        last_name = query.from_user.last_name
        
        # Register or update user info
        db.register_user(user_id, username, first_name, last_name)
        
        # Check subscription status
        subscription = db.check_subscription_status(user_id)
        
        # Store user data for handlers
        data['user_subscription'] = subscription
        
        # Log user activity
        logging.info(f"User {user_id} ({username}) callback: {query.data} [Subscription: {subscription}]")
