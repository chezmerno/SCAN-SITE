import os
import sqlite3
import logging
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, session, g
from werkzeug.security import generate_password_hash, check_password_hash
import config
from utils.scanner import scan_site, scan_site_pro

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

# Database connection helpers
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(config.DB_NAME)
        db.row_factory = sqlite3.Row
    return db

def query_db(query, args=(), one=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv

def init_db():
    db = get_db()
    cursor = db.cursor()
    
    # Create users table if it doesn't exist
    cursor.execute('''CREATE TABLE IF NOT EXISTS users
                    (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                     telegram_id INTEGER UNIQUE, 
                     username TEXT,
                     first_name TEXT,
                     last_name TEXT,
                     password_hash TEXT,
                     attempts INTEGER DEFAULT 5,
                     subscription TEXT DEFAULT 'free',
                     subscription_end_date TEXT,
                     registration_date TEXT DEFAULT CURRENT_TIMESTAMP,
                     is_admin INTEGER DEFAULT 0)''')
    
    # Create scan history table if it doesn't exist
    cursor.execute('''CREATE TABLE IF NOT EXISTS scan_history
                    (id INTEGER PRIMARY KEY AUTOINCREMENT,
                     user_id INTEGER,
                     url TEXT,
                     scan_type TEXT,
                     scan_date TEXT DEFAULT CURRENT_TIMESTAMP,
                     FOREIGN KEY (user_id) REFERENCES users(id))''')
    
    # Check if admin exists, if not create one
    admin = query_db('SELECT * FROM users WHERE telegram_id = ?', [config.ADMIN_ID], one=True)
    if not admin:
        cursor.execute('''INSERT INTO users 
                        (telegram_id, username, first_name, password_hash, is_admin) 
                        VALUES (?, ?, ?, ?, ?)''',
                     (config.ADMIN_ID, 'admin', 'Admin', generate_password_hash('admin123'), 1))
        logging.info("Admin user created successfully")
    
    db.commit()

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Authentication helpers
def login_required(view):
    def wrapped_view(**kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return view(**kwargs)
    wrapped_view.__name__ = view.__name__
    return wrapped_view

def admin_required(view):
    def wrapped_view(**kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user = query_db('SELECT * FROM users WHERE id = ?', [session['user_id']], one=True)
        if not user or not user['is_admin']:
            flash('You do not have permission to access this page', 'danger')
            return redirect(url_for('dashboard'))
        
        return view(**kwargs)
    wrapped_view.__name__ = view.__name__
    return wrapped_view

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = query_db('SELECT * FROM users WHERE username = ?', [username], one=True)
        
        if user and user['password_hash'] and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['is_admin'] = bool(user['is_admin'])
            return redirect(url_for('dashboard'))
        
        flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    # Get statistics
    total_users = query_db('SELECT COUNT(*) as count FROM users', one=True)['count']
    pro_users = query_db('SELECT COUNT(*) as count FROM users WHERE subscription = "pro"', one=True)['count']
    free_users = total_users - pro_users
    recent_scans = query_db('''
        SELECT s.*, u.username, u.first_name, u.telegram_id 
        FROM scan_history s 
        JOIN users u ON s.user_id = u.id 
        ORDER BY s.scan_date DESC LIMIT 10
    ''')
    
    stats = {
        'total_users': total_users,
        'pro_users': pro_users,
        'free_users': free_users,
        'recent_scans': recent_scans
    }
    
    return render_template('dashboard.html', stats=stats)

@app.route('/profile')
@login_required
def profile():
    user = query_db('SELECT * FROM users WHERE id = ?', [session['user_id']], one=True)
    scans = query_db('''
        SELECT * FROM scan_history 
        WHERE user_id = ? 
        ORDER BY scan_date DESC LIMIT 10
    ''', [session['user_id']])
    
    return render_template('profile.html', user=user, scans=scans)

@app.route('/scan', methods=['GET', 'POST'])
@login_required
def scan_website():
    user = query_db('SELECT * FROM users WHERE id = ?', [session['user_id']], one=True)
    
    if request.method == 'POST':
        url = request.form.get('url')
        scan_type = request.form.get('scan_type', 'basic')
        
        if not url:
            flash('Please enter a URL', 'danger')
            return redirect(url_for('scan_website'))
        
        # Check if user can perform this scan
        if scan_type == 'pro' and user['subscription'] != 'pro' and not user['is_admin']:
            flash('PRO scan is only available for PRO subscribers', 'warning')
            return redirect(url_for('scan_website'))
        
        if scan_type == 'basic' and user['subscription'] == 'free' and user['attempts'] <= 0:
            flash('You have used all your free attempts. Upgrade to PRO or wait for reset.', 'warning')
            return redirect(url_for('scan_website'))
        
        try:
            # Perform scan based on type
            if scan_type == 'basic':
                result = scan_site(url)
                
                # Decrement attempts for free users
                if user['subscription'] == 'free':
                    db = get_db()
                    db.execute('UPDATE users SET attempts = attempts - 1 WHERE id = ? AND attempts > 0', [session['user_id']])
                    db.commit()
            else:
                result = scan_site_pro(url)
            
            # Record scan in history
            db = get_db()
            db.execute('''
                INSERT INTO scan_history (user_id, url, scan_type, scan_date) 
                VALUES (?, ?, ?, ?)
            ''', (session['user_id'], url, scan_type, datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')))
            db.commit()
            
            return render_template('scan_result.html', result=result, url=url, scan_type=scan_type)
            
        except Exception as e:
            logging.error(f"Error during scanning: {e}")
            flash(f'Error during scanning: {str(e)}', 'danger')
            return redirect(url_for('scan_website'))
    
    return render_template('scan.html', user=user)

@app.route('/users')
@admin_required
def users():
    users_list = query_db('SELECT * FROM users ORDER BY registration_date DESC')
    return render_template('users.html', users=users_list)

@app.route('/admin/grant_pro/<int:user_id>', methods=['POST'])
@admin_required
def grant_pro(user_id):
    days = int(request.form.get('days', 30))
    
    db = get_db()
    end_date = (datetime.utcnow() + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')
    
    db.execute('''
        UPDATE users 
        SET subscription = 'pro', subscription_end_date = ? 
        WHERE id = ?
    ''', (end_date, user_id))
    db.commit()
    
    flash(f'Successfully granted {days} days of PRO access', 'success')
    return redirect(url_for('users'))

@app.route('/admin/reset_attempts/<int:user_id>', methods=['POST'])
@admin_required
def reset_attempts(user_id):
    db = get_db()
    db.execute('UPDATE users SET attempts = 5 WHERE id = ?', [user_id])
    db.commit()
    
    flash('Successfully reset attempts', 'success')
    return redirect(url_for('users'))

@app.route('/admin/import_data')
@admin_required
def import_data():
    try:
        db = get_db()
        sqlite_db = sqlite3.connect('users.db')
        sqlite_cursor = sqlite_db.cursor()
        
        # Import users
        sqlite_cursor.execute("SELECT * FROM users")
        users = sqlite_cursor.fetchall()
        
        for user_data in users:
            telegram_id = user_data[0]
            username = user_data[1]
            attempts = user_data[2]
            subscription = user_data[3]
            
            # Check if telegram_id already exists
            existing = query_db('SELECT id FROM users WHERE telegram_id = ?', [telegram_id], one=True)
            if existing:
                continue
                
            # Insert user
            db.execute('''
                INSERT INTO users (telegram_id, username, attempts, subscription) 
                VALUES (?, ?, ?, ?)
            ''', (telegram_id, username, attempts, subscription))
        
        # Import scan history if it exists
        try:
            sqlite_cursor.execute("SELECT * FROM scan_history")
            scans = sqlite_cursor.fetchall()
            
            for scan_data in scans:
                scan_id = scan_data[0]
                telegram_id = scan_data[1]
                url = scan_data[2]
                scan_type = scan_data[3]
                scan_date = scan_data[4] if len(scan_data) > 4 else datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
                
                # Get user_id from telegram_id
                user = query_db('SELECT id FROM users WHERE telegram_id = ?', [telegram_id], one=True)
                if not user:
                    continue
                    
                # Insert scan
                db.execute('''
                    INSERT INTO scan_history (user_id, url, scan_type, scan_date) 
                    VALUES (?, ?, ?, ?)
                ''', (user['id'], url, scan_type, scan_date))
        except:
            pass
        
        db.commit()
        sqlite_db.close()
        
        flash('Data imported successfully', 'success')
    except Exception as e:
        logging.error(f"Error importing data: {e}")
        flash(f'Error importing data: {str(e)}', 'danger')
    
    return redirect(url_for('dashboard'))

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

# Initialize database only when in app context
@app.before_request
def before_request():
    if not hasattr(g, 'db_initialized'):
        init_db()
        g.db_initialized = True

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)