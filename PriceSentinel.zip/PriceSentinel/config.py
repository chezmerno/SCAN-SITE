import os

# Bot token
BOT_TOKEN = os.getenv('BOT_TOKEN', '7579503505:AAHdsYRaUwuiWwbjKx_62AYrksfnJqDYAkA')

# Admin ID - this is used to identify admin user
# @portsell Telegram ID
ADMIN_ID = int(os.getenv('ADMIN_ID', '85981555'))

# Subscription settings
FREE_ATTEMPTS = 5  # Number of free scan attempts for non-subscribers
PRO_SUBSCRIPTION_PERIOD = 30  # Days for PRO subscription

# Database settings
DB_NAME = 'users.db'

# Scan types
SCAN_BASIC = 'basic'
SCAN_PRO = 'pro'

# Subscription types
SUB_FREE = 'free'
SUB_PRO = 'pro'

# Default language
DEFAULT_LANGUAGE = 'ru'
