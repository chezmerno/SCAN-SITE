"""
Модуль для поддержания бота в режиме 24/7 без необходимости настроек Replit.
Этот файл самостоятельно обеспечивает непрерывную работу бота.
"""

import sys
import time
import logging
import subprocess
import threading
import requests
import os
import signal
import random

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("Bot24/7")

# Глобальные переменные для отслеживания процессов
bot_process = None
keep_alive_process = None
restart_count = 0

def run_keep_alive():
    """Запускает отдельный процесс для keep_alive сервера"""
    global keep_alive_process
    
    logger.info("Запуск Keep-Alive сервера...")
    try:
        if sys.platform == 'win32':
            # Для Windows
            keep_alive_process = subprocess.Popen([sys.executable, '-c', 
                'from keep_alive import keep_alive; keep_alive()'],
                creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            # Для Linux/Unix
            keep_alive_process = subprocess.Popen([sys.executable, '-c', 
                'from keep_alive import keep_alive; keep_alive()'])
        logger.info("Keep-Alive сервер успешно запущен")
    except Exception as e:
        logger.error(f"Ошибка запуска Keep-Alive сервера: {e}")

def run_bot():
    """Запускает основного бота"""
    global bot_process, restart_count
    
    restart_count += 1
    logger.info(f"Запуск бота (попытка {restart_count})...")
    
    try:
        if sys.platform == 'win32':
            # Для Windows
            bot_process = subprocess.Popen([sys.executable, 'main.py'],
                                          creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            # Для Linux/Unix
            bot_process = subprocess.Popen([sys.executable, 'main.py'])
        logger.info("Бот успешно запущен")
    except Exception as e:
        logger.error(f"Ошибка запуска бота: {e}")

def check_keep_alive():
    """Проверяет работу Keep-Alive сервера"""
    global keep_alive_process
    
    if keep_alive_process is None or keep_alive_process.poll() is not None:
        logger.warning("Keep-Alive сервер не работает. Перезапуск...")
        
        # Если процесс существует, но не работает, завершаем его
        if keep_alive_process is not None:
            try:
                os.kill(keep_alive_process.pid, signal.SIGTERM)
            except:
                pass
        
        # Перезапускаем Keep-Alive
        run_keep_alive()
    else:
        # Проверяем, отвечает ли сервер
        try:
            response = requests.get("http://localhost:8787/", timeout=5)
            if response.status_code == 200:
                logger.info("Keep-Alive сервер работает нормально")
            else:
                logger.warning(f"Keep-Alive сервер вернул код {response.status_code}. Перезапуск...")
                os.kill(keep_alive_process.pid, signal.SIGTERM)
                run_keep_alive()
        except Exception:
            logger.warning("Keep-Alive сервер не отвечает. Перезапуск...")
            try:
                os.kill(keep_alive_process.pid, signal.SIGTERM)
            except:
                pass
            run_keep_alive()

def check_bot():
    """Проверяет работу бота"""
    global bot_process
    
    if bot_process is None or bot_process.poll() is not None:
        logger.warning("Бот не работает. Перезапуск...")
        
        # Если процесс существует, но не работает, завершаем его
        if bot_process is not None:
            try:
                os.kill(bot_process.pid, signal.SIGTERM)
            except:
                pass
        
        # Перезапускаем бота
        run_bot()
    else:
        logger.info("Бот работает нормально")

def ping_replit():
    """Выполняет действия для предотвращения засыпания на Replit"""
    try:
        # Создаем временный файл с случайным именем
        rand_name = f"ping_{random.randint(1000, 9999)}.tmp"
        with open(rand_name, 'w') as f:
            f.write(f"ping at {time.time()}")
        
        # Небольшая задержка
        time.sleep(0.5)
        
        # Удаляем файл
        if os.path.exists(rand_name):
            os.remove(rand_name)
        
        logger.info("Ping успешно выполнен")
    except Exception as e:
        logger.error(f"Ошибка при выполнении ping: {e}")

def monitor_thread():
    """Основной поток мониторинга"""
    check_interval = 60  # Проверка каждую минуту
    ping_interval = 10 * 60  # Ping каждые 10 минут
    
    last_ping_time = time.time()
    
    while True:
        try:
            # Проверяем бота и keep_alive
            check_bot()
            check_keep_alive()
            
            # Выполняем ping по расписанию
            current_time = time.time()
            if current_time - last_ping_time > ping_interval:
                ping_replit()
                last_ping_time = current_time
            
            # Ждем до следующей проверки
            time.sleep(check_interval)
            
        except Exception as e:
            logger.error(f"Ошибка в мониторе: {e}")
            time.sleep(check_interval)

def signal_handler(sig, frame):
    """Обработчик сигнала прерывания"""
    logger.info("Получен сигнал завершения. Останавливаем процессы...")
    
    if keep_alive_process is not None:
        try:
            os.kill(keep_alive_process.pid, signal.SIGTERM)
            logger.info("Keep-Alive сервер остановлен")
        except:
            pass
    
    if bot_process is not None:
        try:
            os.kill(bot_process.pid, signal.SIGTERM)
            logger.info("Бот остановлен")
        except:
            pass
    
    logger.info("Выход из программы")
    sys.exit(0)

if __name__ == "__main__":
    # Регистрируем обработчик сигналов
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    logger.info("=" * 50)
    logger.info("ЗАПУСК СИСТЕМЫ ПОДДЕРЖКИ БОТА 24/7")
    logger.info("=" * 50)
    
    # Запускаем Keep-Alive сервер
    run_keep_alive()
    
    # Даем серверу время на запуск
    time.sleep(3)
    
    # Запускаем бота
    run_bot()
    
    # Запускаем мониторинг в отдельном потоке
    monitor = threading.Thread(target=monitor_thread, daemon=True)
    monitor.start()
    
    logger.info("Система 24/7 успешно запущена. Бот будет работать непрерывно.")
    logger.info("Нажмите Ctrl+C для остановки.")
    
    # Главный поток просто ждет завершения
    try:
        while True:
            time.sleep(60)
            logger.info("Система 24/7 активна и работает")
    except KeyboardInterrupt:
        signal_handler(signal.SIGINT, None)