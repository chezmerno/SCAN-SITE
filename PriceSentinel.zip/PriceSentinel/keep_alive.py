"""
Модуль для поддержания бота в активном состоянии 24/7 на Replit.
Этот модуль использует Always On функциональность Replit.

Чтобы бот работал всегда, нужно:
1. Активировать Always On в настройках Replit
2. Использовать этот модуль для поддержания работы веб-сервера
3. Не закрывать окно браузера с Replit

Always On обеспечивает:
- Непрерывную работу бота 24/7
- Автоматический перезапуск в случае сбоя
- Стабильное соединение с API Telegram
"""
from flask import Flask
from threading import Thread
import logging

app = Flask('')
logging.basicConfig(level=logging.INFO)

@app.route('/')
def home():
    """Возвращает информационную страницу о работе бота"""
    return """
    <html>
    <head>
        <title>Сканер Сайтов - Бот Активен</title>
        <meta charset="utf-8">
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                color: #333;
            }
            .container {
                max-width: 600px;
                background-color: white;
                border-radius: 8px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                padding: 20px;
                text-align: center;
            }
            h1 {
                color: #4a76a8;
            }
            .status {
                font-size: 18px;
                padding: 10px;
                background-color: #e6f7ff;
                border-radius: 4px;
                margin: 20px 0;
            }
            .information {
                text-align: left;
                margin-top: 20px;
            }
            .features {
                list-style-type: none;
                padding: 0;
                text-align: left;
            }
            .features li {
                margin-bottom: 8px;
                padding-left: 20px;
                position: relative;
            }
            .features li:before {
                content: "✓";
                position: absolute;
                left: 0;
                color: #4CAF50;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Сканер Сайтов</h1>
            <div class="status">
                ✅ Телеграм бот активен и работает в режиме Always On
            </div>
            <div class="information">
                <h3>Что умеет бот:</h3>
                <ul class="features">
                    <li>Базовое сканирование сайтов (статус, сервер)</li>
                    <li>PRO-сканирование с подробной информацией</li>
                    <li>Многоязычный интерфейс (русский и английский)</li>
                    <li>Управление подписками пользователей</li>
                    <li>История сканирований</li>
                </ul>
                <p>Чтобы попробовать бота, найдите его в Telegram и отправьте команду /start</p>
            </div>
        </div>
    </body>
    </html>
    """

def run():
    """Запускает веб-сервер в отдельном потоке"""
    app.run(host='0.0.0.0', port=8787)

def keep_alive():
    """Создает и запускает отдельный поток с веб-сервером для 24/7 работы
    
    Эта функция запускает веб-сервер в отдельном потоке, который предотвращает
    остановку бота. Replit видит активный веб-сервер и не останавливает проект.
    
    Примечание: Для полноценной работы 24/7 рекомендуется также включить
    функцию Always On в настройках Replit (если доступно).
    """
    try:
        t = Thread(target=run)
        t.daemon = True  # Поток завершится, когда завершится основная программа
        t.start()
        logging.info("Сервер 24/7 успешно запущен! Бот будет работать непрерывно.")
        
        # Добавим регулярную проверку состояния сервера
        def check_server_status():
            while True:
                try:
                    # Проверка каждые 5 минут
                    import time
                    time.sleep(300)
                    logging.info("Сервер 24/7 активен и работает")
                except Exception as e:
                    logging.error(f"Ошибка проверки статуса: {e}")
        
        # Запустим проверку в отдельном потоке
        status_thread = Thread(target=check_server_status)
        status_thread.daemon = True
        status_thread.start()
    except Exception as e:
        logging.error(f"Ошибка запуска сервера 24/7: {e}")