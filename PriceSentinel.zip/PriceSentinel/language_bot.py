import logging
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Replace with your actual bot token
BOT_TOKEN = "7579503505:AAHdsYRaUwuiWwbjKx_62AYrksfnJqDYAkA"

# Initialize bot and dispatcher
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

# Dictionary to store each user's language preference
user_lang = {}

@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    """Handle the start command"""
    user_lang[message.from_user.id] = "en"  # Default to English
    await message.reply("Welcome! Send: language ru or language en to set your preferred language.")

@dp.message_handler(lambda msg: msg.text.lower().startswith("language "))
async def set_language(message: types.Message):
    """Handle language change requests"""
    lang = message.text.lower().split("language ")[1].strip()
    if lang in ["ru", "en"]:
        user_lang[message.from_user.id] = lang
        if lang == "ru":
            await message.reply("Язык установлен на русский.")
        else:
            await message.reply("Language set to English.")
    else:
        await message.reply("Unknown language. Use: ru or en")

@dp.message_handler()
async def any_message(message: types.Message):
    """Handle all other messages based on user's language preference"""
    lang = user_lang.get(message.from_user.id, "en")
    if lang == "ru":
        await message.reply("Это русский текст.")
    else:
        await message.reply("This is English text.")

if __name__ == "__main__":
    logging.info("Starting language bot")
    executor.start_polling(dp, skip_updates=True)