"""
Web application entry point for the Website Scanner Service.
This file contains the Flask app to be used with Gunicorn.
"""

from simple_web import app

# This is what Gunicorn will look for
application = app

# For running directly
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)