import logging
from aiogram import Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
import config
import database as db
from keyboards import get_admin_panel_keyboard, get_back_to_main_keyboard
from translations import get_message

class AdminStates(StatesGroup):
    """State machine for admin operations"""
    waiting_for_user_id = State()
    waiting_for_pro_days = State()

async def cmd_admin(message: types.Message):
    """Admin command handler - access to admin features"""
    user_id = message.from_user.id
    
    # Check if user is admin
    if user_id != config.ADMIN_ID:
        # Get user's language
        language = db.get_user_language(user_id)
        await message.answer(get_message('admin.no_rights', language))
        return
    
    # Get admin's language preference
    language = db.get_user_language(user_id)
    
    await message.answer(
        f"👑 {get_message('admin.welcome', language)}\n\n"
        f"{get_message('main_menu.prompt', language)}",
        reply_markup=get_admin_panel_keyboard(language)
    )

async def process_admin_callback(callback_query: types.CallbackQuery, state: FSMContext):
    """Handle admin panel callback queries"""
    user_id = callback_query.from_user.id
    
    # Get admin's language preference
    language = db.get_user_language(user_id)
    
    # Check if user is admin
    if user_id != config.ADMIN_ID:
        await callback_query.answer(get_message('admin.no_rights', language), show_alert=True)
        return
    
    callback_data = callback_query.data
    
    if callback_data == "admin_user_list":
        # Get all users and display them
        users = db.get_all_users()
        if not users:
            await callback_query.message.edit_text(
                "No users found in the database.",
                reply_markup=get_back_to_main_keyboard()
            )
            return
        
        user_list = f"👥 {get_message('admin_panel.user_list', language)}:\n\n"
        for user in users[:15]:  # Limit to 15 users to avoid message size limit
            user_id, username, first_name, last_name, attempts, subscription, sub_end = user
            user_display = username or first_name or str(user_id)
            user_list += f"ID: {user_id} | @{user_display} | {subscription.upper()} | {get_message('profile', language, attempts=attempts)}"
            if sub_end and subscription == config.SUB_PRO:
                user_list += f" | Until: {sub_end[:10]}"
            user_list += "\n"
        
        user_list += f"\n{get_message('admin.users_count', language, users_count=len(users))}"
        
        await callback_query.message.edit_text(
            user_list,
            reply_markup=get_back_to_main_keyboard()
        )
    
    elif callback_data == "admin_stats":
        # Show basic stats about the bot
        users = db.get_all_users()
        total_users = len(users)
        pro_users = sum(1 for user in users if user[5] == config.SUB_PRO)
        free_users = total_users - pro_users
        
        stats = (
            f"📊 {get_message('admin_panel.stats', language)}\n\n"
            f"{get_message('admin.users_count', language, users_count=total_users)}\n"
            f"PRO: {pro_users}\n"
            f"{get_message('subscription.free', language)}: {free_users}\n"
        )
        
        await callback_query.message.edit_text(
            stats,
            reply_markup=get_back_to_main_keyboard()
        )
    
    elif callback_data == "admin_grant_pro":
        await callback_query.message.edit_text(
            get_message('admin.user_id_prompt', language),
            reply_markup=get_back_to_main_keyboard()
        )
        await AdminStates.waiting_for_user_id.set()
    
    await callback_query.answer()

async def process_user_id_input(message: types.Message, state: FSMContext):
    """Process admin input for user ID to grant PRO access"""
    # Get admin's language preference
    language = db.get_user_language(message.from_user.id)
    
    try:
        user_id = int(message.text.strip())
        
        # Check if user exists
        user = db.get_user(user_id)
        if not user:
            await message.answer(
                get_message('admin.user_not_found', language),
                reply_markup=get_back_to_main_keyboard()
            )
            await state.finish()
            return
        
        await state.update_data(target_user_id=user_id)
        username = user[1] or user[2] or str(user[0])
        
        await message.answer(
            f"{get_message('admin.user_stats', language, user_id=user_id, username=username, attempts=user[4], subscription=user[5].upper())}\n\n"
            f"{get_message('admin.days_prompt', language)}",
            reply_markup=get_back_to_main_keyboard()
        )
        await AdminStates.waiting_for_pro_days.set()
    
    except ValueError:
        await message.answer(
            get_message('invalid_input', language, type="user ID"),
            reply_markup=get_back_to_main_keyboard()
        )
        await state.finish()

async def process_pro_days_input(message: types.Message, state: FSMContext):
    """Process admin input for number of PRO access days"""
    # Get admin's language preference
    language = db.get_user_language(message.from_user.id)
    
    try:
        days = int(message.text.strip())
        if days <= 0:
            await message.answer(get_message('invalid_input', language, type="days"))
            return
        
        # Get user ID from state
        data = await state.get_data()
        target_user_id = data.get('target_user_id')
        
        # Update user subscription
        db.update_user_subscription(target_user_id, config.SUB_PRO, days)
        
        await message.answer(
            get_message('admin.pro_granted', language, user_id=target_user_id, days=days),
            reply_markup=get_back_to_main_keyboard()
        )
        await state.finish()
        
        # Get user's language
        user_language = db.get_user_language(target_user_id)
        
        # Notify the user about their new PRO status
        try:
            from main import bot
            await bot.send_message(
                target_user_id,
                f"🎁 {get_message('pro_granted_notification', user_language, days=days)}",
                parse_mode="Markdown"
            )
        except Exception as e:
            logging.error(f"Failed to notify user {target_user_id}: {e}")
    
    except ValueError:
        await message.answer(
            get_message('invalid_input', language, type="days"),
            reply_markup=get_back_to_main_keyboard()
        )
        await state.finish()

def register_admin_handlers(dp: Dispatcher):
    """Register admin handlers"""
    dp.register_message_handler(cmd_admin, commands=["admin"])
    dp.register_message_handler(cmd_admin, lambda msg: msg.text == "👑 Admin Panel")
    
    # Admin callback handlers
    dp.register_callback_query_handler(
        process_admin_callback,
        lambda c: c.data.startswith("admin_"),
    )
    
    # State handlers for admin operations
    dp.register_message_handler(
        process_user_id_input,
        state=AdminStates.waiting_for_user_id
    )
    dp.register_message_handler(
        process_pro_days_input,
        state=AdminStates.waiting_for_pro_days
    )
