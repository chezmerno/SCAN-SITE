from flask import render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import sqlite3
import logging
import config
from app import app, db
from models import User, ScanHistory
from utils.scanner import scan_site, scan_site_pro

# Setup login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # type: ignore

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Helper functions
def get_user_stats():
    """Get basic user statistics for dashboard"""
    total_users = User.query.count()
    pro_users = User.query.filter_by(subscription="pro").count()
    free_users = total_users - pro_users
    recent_scans = ScanHistory.query.order_by(ScanHistory.scan_date.desc()).limit(10).all()
    
    return {
        'total_users': total_users,
        'pro_users': pro_users,
        'free_users': free_users,
        'recent_scans': recent_scans
    }

def import_from_sqlite():
    """Import data from SQLite database to SQLAlchemy models"""
    try:
        # Connect to SQLite database
        conn = sqlite3.connect(config.DB_NAME)
        cursor = conn.cursor()
        
        # Import users
        cursor.execute("SELECT * FROM users")
        users = cursor.fetchall()
        
        for user_data in users:
            user_id, username, first_name, last_name, attempts, subscription, sub_end, reg_date = user_data
            
            # Check if user already exists in new database
            existing_user = User.query.filter_by(telegram_id=user_id).first()
            if existing_user:
                continue
                
            # Convert dates
            if sub_end:
                sub_end_date = datetime.strptime(sub_end, '%Y-%m-%d %H:%M:%S')
            else:
                sub_end_date = None
                
            if reg_date:
                registration_date = datetime.strptime(reg_date, '%Y-%m-%d %H:%M:%S')
            else:
                registration_date = datetime.utcnow()
            
            # Create new user in SQLAlchemy model
            new_user = User()
            new_user.telegram_id = user_id
            new_user.username = username
            new_user.first_name = first_name
            new_user.last_name = last_name
            new_user.attempts = attempts or 5
            new_user.subscription = subscription or "free"
            new_user.subscription_end_date = sub_end_date
            new_user.registration_date = registration_date
            db.session.add(new_user)
        
        # Import scan history
        cursor.execute("SELECT * FROM scan_history")
        scans = cursor.fetchall()
        
        for scan_data in scans:
            scan_id, user_id, url, scan_type, scan_date = scan_data
            
            # Find user by telegram_id
            user = User.query.filter_by(telegram_id=user_id).first()
            if not user:
                continue
                
            # Convert date
            if scan_date:
                scan_date = datetime.strptime(scan_date, '%Y-%m-%d %H:%M:%S')
            else:
                scan_date = datetime.utcnow()
            
            # Create new scan history entry
            new_scan = ScanHistory()
            new_scan.user_id = user.id
            new_scan.url = url
            new_scan.scan_type = scan_type
            new_scan.scan_date = scan_date
            db.session.add(new_scan)
            
        # Commit all changes
        db.session.commit()
        conn.close()
        return True
    except Exception as e:
        logging.error(f"Error importing data: {e}")
        db.session.rollback()
        return False

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.password_hash and password and check_password_hash(user.password_hash, str(password)):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        
        flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    stats = get_user_stats()
    return render_template('dashboard.html', stats=stats)

@app.route('/profile')
@login_required
def profile():
    user_scans = ScanHistory.query.filter_by(user_id=current_user.id).order_by(ScanHistory.scan_date.desc()).limit(10).all()
    return render_template('profile.html', user=current_user, scans=user_scans)

@app.route('/users')
@login_required
def users():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('dashboard'))
        
    users_list = User.query.order_by(User.registration_date.desc()).all()
    return render_template('users.html', users=users_list)

@app.route('/scan', methods=['GET', 'POST'])
@login_required
def scan():
    if request.method == 'POST':
        url = request.form.get('url')
        scan_type = request.form.get('scan_type', 'basic')
        
        if not url:
            flash('Please enter a URL', 'danger')
            return redirect(url_for('scan'))
            
        # Check if user can perform this scan
        if scan_type == 'pro' and not current_user.is_pro() and not current_user.is_admin:
            flash('PRO scan is only available for PRO subscribers', 'warning')
            return redirect(url_for('scan'))
            
        if scan_type == 'basic' and current_user.subscription == 'free' and current_user.attempts <= 0:
            flash('You have used all your free attempts. Upgrade to PRO or wait for reset.', 'warning')
            return redirect(url_for('scan'))
            
        try:
            # Perform scan based on type
            if scan_type == 'basic':
                result = scan_site(url)
                
                # Decrement attempts for free users
                if current_user.subscription == 'free':
                    current_user.attempts -= 1
                    db.session.commit()
            else:
                result = scan_site_pro(url)
                
            # Record scan in history
            new_scan = ScanHistory()
            new_scan.user_id = current_user.id
            new_scan.url = url
            new_scan.scan_type = scan_type
            new_scan.scan_date = datetime.utcnow()
            db.session.add(new_scan)
            db.session.commit()
            
            return render_template('scan_result.html', result=result, url=url, scan_type=scan_type)
            
        except Exception as e:
            flash(f'Error during scanning: {str(e)}', 'danger')
            return redirect(url_for('scan'))
    
    return render_template('scan.html', user=current_user)

@app.route('/admin/grant_pro/<int:user_id>', methods=['POST'])
@login_required
def grant_pro(user_id):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('dashboard'))
        
    user = User.query.get(user_id)
    if not user:
        flash('User not found', 'danger')
        return redirect(url_for('users'))
        
    days = int(request.form.get('days', 30))
    
    user.subscription = 'pro'
    user.subscription_end_date = datetime.utcnow() + timedelta(days=days)
    db.session.commit()
    
    flash(f'Successfully granted {days} days of PRO access to user {user.username or user.telegram_id}', 'success')
    return redirect(url_for('users'))

@app.route('/admin/reset_attempts/<int:user_id>', methods=['POST'])
@login_required
def reset_attempts(user_id):
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('dashboard'))
        
    user = User.query.get(user_id)
    if not user:
        flash('User not found', 'danger')
        return redirect(url_for('users'))
        
    user.attempts = 5  # Reset to default free attempts
    db.session.commit()
    
    flash(f'Successfully reset attempts for user {user.username or user.telegram_id}', 'success')
    return redirect(url_for('users'))

@app.route('/admin/import_data', methods=['GET'])
@login_required
def import_data():
    if not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('dashboard'))
        
    success = import_from_sqlite()
    
    if success:
        flash('Data imported successfully', 'success')
    else:
        flash('Error importing data', 'danger')
        
    return redirect(url_for('dashboard'))

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500